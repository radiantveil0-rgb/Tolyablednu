package com.tolyabledny.audiojoin

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.media.MediaPlayer
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.ViewGroup
import android.widget.Button
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileOutputStream
import java.util.Locale

class MainActivity : Activity() {

    companion object {
        const val REQ_PICK = 1
        const val REQ_SAVE = 2
        const val MAX_FADE_MS = 5000.0
        const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
        const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
    }

    private val tracks = mutableListOf<Track>()
    private val waves = mutableListOf<WaveformView>()
    private var fadeOutMs = 10
    private var fadeInMs = 10
    private var overlap = false
    private var busy = false
    private var player: MediaPlayer? = null

    private lateinit var list: LinearLayout
    private lateinit var status: TextView
    private lateinit var foLabel: TextView
    private lateinit var fiLabel: TextView
    private lateinit var playBtn: Button

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun label(t: String, size: Float, color: Int): TextView {
        val tv = TextView(this)
        tv.text = t
        tv.textSize = size
        tv.setTextColor(color)
        return tv
    }

    // ползунок 0..1000 -> миллисекунды (квадратичная шкала: точная настройка у малых значений)
    private fun msFrom(p: Int): Int = Math.round(p.toDouble() * p / 1_000_000.0 * MAX_FADE_MS).toInt()
    private fun pFrom(ms: Int): Int = Math.round(Math.sqrt(ms / MAX_FADE_MS) * 1000).toInt()

    private fun seek(initialMs: Int, onChange: (Int) -> Unit): SeekBar {
        val sb = SeekBar(this)
        sb.max = 1000
        sb.progress = pFrom(initialMs)
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) { onChange(msFrom(p)) }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        return sb
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(12), dp(12), dp(12), dp(12))

        root.addView(label("Склейка аудио", 22f, Color.BLACK))
        root.addView(label("Разработчик: Толя Бледный", 12f, Color.GRAY))

        val addBtn = Button(this)
        addBtn.text = "+ Добавить файлы"
        addBtn.setOnClickListener { pick() }
        root.addView(addBtn)

        list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL
        val scroll = ScrollView(this)
        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(MATCH, 0, 1f))

        foLabel = label("", 14f, Color.BLACK)
        fiLabel = label("", 14f, Color.BLACK)
        root.addView(foLabel)
        root.addView(seek(fadeOutMs) { fadeOutMs = it; updateLabels(); updateFades() })
        root.addView(fiLabel)
        root.addView(seek(fadeInMs) { fadeInMs = it; updateLabels(); updateFades() })

        val cb = CheckBox(this)
        cb.text = "Накладывать друг на друга (кроссфейд)"
        cb.setOnCheckedChangeListener { _, v -> overlap = v }
        root.addView(cb)

        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        playBtn = Button(this)
        playBtn.text = "▶ Прослушать"
        playBtn.setOnClickListener { preview() }
        val saveBtn = Button(this)
        saveBtn.text = "Сохранить WAV"
        saveBtn.setOnClickListener { save() }
        row.addView(playBtn, LinearLayout.LayoutParams(0, WRAP, 1f))
        row.addView(saveBtn, LinearLayout.LayoutParams(0, WRAP, 1f))
        root.addView(row)

        status = label("Добавь аудиофайлы", 13f, Color.DKGRAY)
        root.addView(status)

        setContentView(root)
        updateLabels()
        refreshList()
        handleIntent(intent)
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    // файлы, пришедшие через «Открыть с помощью» / «Поделиться»
    @Suppress("DEPRECATION")
    private fun handleIntent(i: Intent?) {
        if (i == null || busy) return
        val uris = mutableListOf<Uri>()
        when (i.action) {
            Intent.ACTION_VIEW -> i.data?.let { uris.add(it) }
            Intent.ACTION_SEND -> (i.getParcelableExtra<Uri>(Intent.EXTRA_STREAM))?.let { uris.add(it) }
            Intent.ACTION_SEND_MULTIPLE -> i.getParcelableArrayListExtra<Uri>(Intent.EXTRA_STREAM)?.let { uris.addAll(it) }
        }
        if (uris.isNotEmpty()) {
            i.action = null
            importUris(uris)
        }
    }

    private fun updateLabels() {
        foLabel.text = "Затухание конца предыдущего: $fadeOutMs мс"
        fiLabel.text = "Нарастание начала следующего: $fadeInMs мс"
    }

    private fun updateFades() {
        waves.forEachIndexed { i, w ->
            val d = tracks[i].durationMs.toFloat().coerceAtLeast(1f)
            w.fadeIn = if (i > 0) (fadeInMs / d).coerceAtMost(1f) else 0f
            w.fadeOut = if (i < tracks.size - 1) (fadeOutMs / d).coerceAtMost(1f) else 0f
        }
    }

    private fun fmt(ms: Long): String =
        String.format(Locale.US, "%d:%04.1f", ms / 60000, (ms % 60000) / 1000.0)

    private fun smallBtn(t: String, action: () -> Unit): Button {
        val b = Button(this)
        b.text = t
        b.minWidth = 0
        b.minimumWidth = dp(56)
        b.setOnClickListener { action() }
        return b
    }

    private fun refreshList() {
        if (player != null) stopPlayer()
        list.removeAllViews()
        waves.clear()
        if (tracks.isEmpty()) {
            list.addView(label("\nПока пусто. Нажми «+ Добавить файлы» (mp3, m4a, ogg, wav, flac…).", 14f, Color.GRAY))
        }
        tracks.forEachIndexed { i, t ->
            val card = LinearLayout(this)
            card.orientation = LinearLayout.VERTICAL
            card.setPadding(dp(8), dp(6), dp(8), dp(6))
            card.setBackgroundColor(0xFFEFEFEF.toInt())

            card.addView(label("${i + 1}. ${t.name}  •  ${fmt(t.durationMs)}", 14f, Color.BLACK))

            val w = WaveformView(this)
            w.peaks = t.peaks
            card.addView(w, LinearLayout.LayoutParams(MATCH, dp(64)))
            waves.add(w)

            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.addView(smallBtn("↑") { move(i, -1) })
            row.addView(smallBtn("↓") { move(i, 1) })
            row.addView(smallBtn("✕") { remove(i) })
            card.addView(row)

            val lp = LinearLayout.LayoutParams(MATCH, WRAP)
            lp.topMargin = dp(8)
            list.addView(card, lp)
        }
        updateFades()
    }

    private fun move(i: Int, d: Int) {
        val j = i + d
        if (busy || j < 0 || j >= tracks.size) return
        val t = tracks.removeAt(i)
        tracks.add(j, t)
        refreshList()
    }

    private fun remove(i: Int) {
        if (busy) return
        tracks[i].file.delete()
        tracks.removeAt(i)
        refreshList()
    }

    // ---------- выбор файлов ----------
    private fun pick() {
        if (busy) { Toast.makeText(this, "Подожди, идёт работа…", Toast.LENGTH_SHORT).show(); return }
        val it = Intent(Intent.ACTION_OPEN_DOCUMENT)
        it.addCategory(Intent.CATEGORY_OPENABLE)
        it.type = "audio/*"
        it.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
        @Suppress("DEPRECATION")
        startActivityForResult(it, REQ_PICK)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK || data == null) return
        when (requestCode) {
            REQ_PICK -> {
                val uris = mutableListOf<Uri>()
                val cd = data.clipData
                if (cd != null) {
                    for (i in 0 until cd.itemCount) uris.add(cd.getItemAt(i).uri)
                } else {
                    data.data?.let { uris.add(it) }
                }
                importUris(uris)
            }
            REQ_SAVE -> data.data?.let { export(it) }
        }
    }

    private fun displayName(u: Uri): String {
        try {
            contentResolver.query(u, null, null, null, null)?.use { c ->
                val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (i >= 0 && c.moveToFirst()) return c.getString(i)
            }
        } catch (_: Exception) {}
        return u.lastPathSegment ?: "audio"
    }

    private fun importUris(uris: List<Uri>) {
        busy = true
        Thread {
            for (u in uris) {
                val name = displayName(u)
                runOnUiThread { status.text = "Загружаю: $name …" }
                val f = File(cacheDir, "t_${System.nanoTime()}.pcm")
                try {
                    val t = AudioEngine.importTrack(this, u, name, f)
                    runOnUiThread { tracks.add(t); refreshList() }
                } catch (e: Throwable) {
                    f.delete()
                    runOnUiThread {
                        Toast.makeText(this, "Не получилось: $name (${e.message})", Toast.LENGTH_LONG).show()
                    }
                }
            }
            runOnUiThread { busy = false; status.text = "Готово. Файлов: ${tracks.size}" }
        }.start()
    }

    // ---------- сохранение и прослушивание ----------
    private fun settings() = AudioEngine.Settings(fadeOutMs, fadeInMs, overlap)

    private fun save() {
        if (busy) { Toast.makeText(this, "Подожди, идёт работа…", Toast.LENGTH_SHORT).show(); return }
        if (tracks.isEmpty()) { Toast.makeText(this, "Сначала добавь файлы", Toast.LENGTH_SHORT).show(); return }
        val it = Intent(Intent.ACTION_CREATE_DOCUMENT)
        it.addCategory(Intent.CATEGORY_OPENABLE)
        it.type = "audio/wav"
        it.putExtra(Intent.EXTRA_TITLE, "склейка.wav")
        @Suppress("DEPRECATION")
        startActivityForResult(it, REQ_SAVE)
    }

    private fun export(uri: Uri) {
        busy = true
        val tr = tracks.toList()
        val s = settings()
        Thread {
            var last = -1
            try {
                val os = contentResolver.openOutputStream(uri) ?: throw java.io.IOException("не открыть файл")
                BufferedOutputStream(os, 1 shl 16).use { out ->
                    AudioEngine.mixTo(tr, s, out) { p ->
                        if (p != last) { last = p; runOnUiThread { status.text = "Склейка: $p%" } }
                    }
                }
                runOnUiThread { status.text = "Сохранено ✔"; Toast.makeText(this, "Сохранено", Toast.LENGTH_LONG).show() }
            } catch (e: Throwable) {
                runOnUiThread { status.text = "Ошибка: ${e.message}" }
            } finally {
                runOnUiThread { busy = false }
            }
        }.start()
    }

    private fun preview() {
        if (player != null) { stopPlayer(); return }
        if (busy) return
        if (tracks.isEmpty()) { Toast.makeText(this, "Сначала добавь файлы", Toast.LENGTH_SHORT).show(); return }
        busy = true
        val tr = tracks.toList()
        val s = settings()
        Thread {
            var last = -1
            try {
                val f = File(cacheDir, "preview.wav")
                BufferedOutputStream(FileOutputStream(f), 1 shl 16).use { out ->
                    AudioEngine.mixTo(tr, s, out) { p ->
                        if (p != last) { last = p; runOnUiThread { status.text = "Готовлю прослушивание: $p%" } }
                    }
                }
                runOnUiThread {
                    try {
                        val mp = MediaPlayer()
                        mp.setDataSource(f.absolutePath)
                        mp.setOnCompletionListener { stopPlayer() }
                        mp.prepare()
                        mp.start()
                        player = mp
                        playBtn.text = "■ Стоп"
                        status.text = "Играет…"
                    } catch (e: Throwable) {
                        status.text = "Ошибка воспроизведения: ${e.message}"
                    }
                }
            } catch (e: Throwable) {
                runOnUiThread { status.text = "Ошибка: ${e.message}" }
            } finally {
                runOnUiThread { busy = false }
            }
        }.start()
    }

    private fun stopPlayer() {
        try { player?.stop() } catch (_: Exception) {}
        try { player?.release() } catch (_: Exception) {}
        player = null
        playBtn.text = "▶ Прослушать"
    }

    override fun onDestroy() {
        super.onDestroy()
        try { player?.release() } catch (_: Exception) {}
        if (isFinishing) {
            cacheDir.listFiles()?.forEach { if (it.name.startsWith("t_") || it.name == "preview.wav") it.delete() }
        }
    }
}
