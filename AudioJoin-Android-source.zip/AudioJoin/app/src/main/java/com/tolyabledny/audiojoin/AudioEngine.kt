package com.tolyabledny.audiojoin

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

const val RATE = 44100

/** Трек: сырой PCM во временном файле (16 бит, стерео, 44100 Гц) + огибающая громкости. */
class Track(
    val name: String,
    val file: File,
    val frames: Long,
    val peaks: FloatArray
) {
    val durationMs: Long get() = frames * 1000L / RATE
}

object AudioEngine {

    class Settings(val fadeOutMs: Int, val fadeInMs: Int, val overlap: Boolean)

    // ---------- Ресемплер (линейный) ----------
    private class Resampler(srcRate: Int, private val emit: (Short, Short) -> Unit) {
        private val step = srcRate.toDouble() / RATE
        private var t = 0.0
        private var n = 0L
        private var pl = 0f
        private var pr = 0f

        fun push(l: Short, r: Short) {
            val cl = l.toFloat()
            val cr = r.toFloat()
            if (n == 0L) { pl = cl; pr = cr }
            while (t <= n) {
                val f = (t - (n - 1)).toFloat()
                emit((pl + (cl - pl) * f).toInt().toShort(), (pr + (cr - pr) * f).toInt().toShort())
                t += step
            }
            pl = cl; pr = cr; n++
        }
    }

    // ---------- Декодирование любого аудио в PCM ----------
    fun importTrack(ctx: Context, uri: Uri, name: String, outFile: File): Track {
        val ex = MediaExtractor()
        var codec: MediaCodec? = null
        val out = BufferedOutputStream(FileOutputStream(outFile), 1 shl 16)
        var frames = 0L
        try {
            ex.setDataSource(ctx, uri, null)
            var idx = -1
            var fmt: MediaFormat? = null
            for (i in 0 until ex.trackCount) {
                val f = ex.getTrackFormat(i)
                if ((f.getString(MediaFormat.KEY_MIME) ?: "").startsWith("audio/")) {
                    idx = i; fmt = f; break
                }
            }
            if (idx < 0 || fmt == null) throw IOException("нет аудио-дорожки")
            ex.selectTrack(idx)
            val mime = fmt.getString(MediaFormat.KEY_MIME)!!
            var rate = fmt.getInteger(MediaFormat.KEY_SAMPLE_RATE)
            var ch = fmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT)

            val dec = MediaCodec.createDecoderByType(mime)
            codec = dec
            dec.configure(fmt, null, null, 0)
            dec.start()

            val bytes = ByteArray(4)
            val writeFrame: (Short, Short) -> Unit = { l, r ->
                bytes[0] = l.toInt().toByte()
                bytes[1] = (l.toInt() shr 8).toByte()
                bytes[2] = r.toInt().toByte()
                bytes[3] = (r.toInt() shr 8).toByte()
                out.write(bytes)
                frames++
            }
            var rs: Resampler? = null
            val info = MediaCodec.BufferInfo()
            var inDone = false
            var outDone = false

            while (!outDone) {
                if (!inDone) {
                    val ii = dec.dequeueInputBuffer(10_000)
                    if (ii >= 0) {
                        val buf = dec.getInputBuffer(ii)!!
                        val n = ex.readSampleData(buf, 0)
                        if (n < 0) {
                            dec.queueInputBuffer(ii, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inDone = true
                        } else {
                            dec.queueInputBuffer(ii, 0, n, ex.sampleTime, 0)
                            ex.advance()
                        }
                    }
                }
                val oi = dec.dequeueOutputBuffer(info, 10_000)
                if (oi >= 0) {
                    if (info.size > 0) {
                        val ob = dec.getOutputBuffer(oi)!!
                        ob.position(info.offset)
                        ob.limit(info.offset + info.size)
                        val sb = ob.order(ByteOrder.LITTLE_ENDIAN).asShortBuffer()
                        if (rs == null && rate != RATE) rs = Resampler(rate, writeFrame)
                        val cnt = sb.remaining() / ch
                        for (i in 0 until cnt) {
                            val l = sb.get()
                            var r = l
                            if (ch >= 2) {
                                r = sb.get()
                                for (k in 2 until ch) sb.get()
                            }
                            if (rs != null) rs.push(l, r) else writeFrame(l, r)
                        }
                    }
                    dec.releaseOutputBuffer(oi, false)
                    if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) outDone = true
                } else if (oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    val nf = dec.outputFormat
                    rate = nf.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                    ch = nf.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                }
            }
        } finally {
            try { codec?.stop() } catch (_: Exception) {}
            try { codec?.release() } catch (_: Exception) {}
            ex.release()
            out.close()
        }
        if (frames == 0L) throw IOException("файл пустой или формат не поддерживается")
        return Track(name, outFile, frames, waveform(outFile, frames))
    }

    private fun fill(ins: InputStream, buf: ByteArray): Int {
        var t = 0
        while (t < buf.size) {
            val n = ins.read(buf, t, buf.size - t)
            if (n < 0) break
            t += n
        }
        return t
    }

    // ---------- Огибающая громкости ----------
    private fun waveform(file: File, frames: Long, buckets: Int = 1000): FloatArray {
        val peaks = FloatArray(buckets)
        val buf = ByteArray(4 * 8192)
        var idx = 0L
        FileInputStream(file).use { ins ->
            while (true) {
                val n = fill(ins, buf)
                if (n < 4) break
                var p = 0
                while (p + 3 < n) {
                    val l = abs((buf[p + 1].toInt() shl 8) or (buf[p].toInt() and 0xFF))
                    val r = abs((buf[p + 3].toInt() shl 8) or (buf[p + 2].toInt() and 0xFF))
                    val v = max(l, r) / 32768f
                    val b = (idx * buckets / frames).toInt().coerceAtMost(buckets - 1)
                    if (v > peaks[b]) peaks[b] = v
                    idx++
                    p += 4
                }
                if (n < buf.size) break
            }
        }
        return peaks
    }

    // ---------- Склейка ----------
    private fun layout(tracks: List<Track>, s: Settings): Pair<LongArray, Long> {
        val foF = s.fadeOutMs.toLong() * RATE / 1000
        val fiF = s.fadeInMs.toLong() * RATE / 1000
        val starts = LongArray(tracks.size)
        var total = 0L
        for (i in tracks.indices) {
            if (i > 0) {
                val prev = tracks[i - 1]
                val cur = tracks[i]
                var ov = if (s.overlap) max(foF, fiF) else 0L
                ov = min(ov, min(prev.frames, cur.frames))
                starts[i] = starts[i - 1] + prev.frames - ov
            }
            total = max(total, starts[i] + tracks[i].frames)
        }
        return Pair(starts, total)
    }

    private fun wavHeader(frames: Long): ByteArray {
        val dataSize = (frames * 4).coerceAtMost(0xFFFFFFFFL - 36)
        val bb = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
        bb.put("RIFF".toByteArray())
        bb.putInt((36 + dataSize).toInt())
        bb.put("WAVE".toByteArray())
        bb.put("fmt ".toByteArray())
        bb.putInt(16)
        bb.putShort(1)
        bb.putShort(2)
        bb.putInt(RATE)
        bb.putInt(RATE * 4)
        bb.putShort(4)
        bb.putShort(16)
        bb.put("data".toByteArray())
        bb.putInt(dataSize.toInt())
        return bb.array()
    }

    fun mixTo(tracks: List<Track>, s: Settings, out: OutputStream, progress: (Int) -> Unit) {
        val n = tracks.size
        val (starts, total) = layout(tracks, s)
        val foF = s.fadeOutMs.toLong() * RATE / 1000
        val fiF = s.fadeInMs.toLong() * RATE / 1000
        val fi = LongArray(n) { i -> if (i > 0) min(fiF, tracks[i].frames) else 0L }
        val fo = LongArray(n) { i -> if (i < n - 1) min(foF, tracks[i].frames) else 0L }

        out.write(wavHeader(total))
        val files = tracks.map { RandomAccessFile(it.file, "r") }
        try {
            val block = 16384
            val acc = FloatArray(block * 2)
            val raw = ByteArray(block * 4)
            val outb = ByteArray(block * 4)
            var pos = 0L
            while (pos < total) {
                val len = min(block.toLong(), total - pos).toInt()
                java.util.Arrays.fill(acc, 0, len * 2, 0f)
                for (i in 0 until n) {
                    val t = tracks[i]
                    val s0 = starts[i]
                    val s1 = s0 + t.frames
                    val a = max(pos, s0)
                    val b = min(pos + len, s1)
                    if (a >= b) continue
                    val cnt = (b - a).toInt()
                    val raf = files[i]
                    raf.seek((a - s0) * 4)
                    raf.readFully(raw, 0, cnt * 4)
                    for (k in 0 until cnt) {
                        val local = a - s0 + k
                        var g = 1f
                        if (local < fi[i]) g *= (local + 0.5f) / fi[i]
                        val rem = t.frames - local
                        if (rem <= fo[i]) g *= (rem - 0.5f) / fo[i]
                        val l = (raw[k * 4 + 1].toInt() shl 8) or (raw[k * 4].toInt() and 0xFF)
                        val r = (raw[k * 4 + 3].toInt() shl 8) or (raw[k * 4 + 2].toInt() and 0xFF)
                        val o = (a - pos).toInt() + k
                        acc[o * 2] += l * g
                        acc[o * 2 + 1] += r * g
                    }
                }
                for (j in 0 until len * 2) {
                    val v = acc[j].roundToInt().coerceIn(-32768, 32767)
                    outb[j * 2] = v.toByte()
                    outb[j * 2 + 1] = (v shr 8).toByte()
                }
                out.write(outb, 0, len * 4)
                pos += len
                progress((pos * 100 / total).toInt())
            }
        } finally {
            files.forEach { it.close() }
        }
        out.flush()
    }
}
