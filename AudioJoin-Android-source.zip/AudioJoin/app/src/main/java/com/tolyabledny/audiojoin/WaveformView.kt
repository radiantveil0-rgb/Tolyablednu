package com.tolyabledny.audiojoin

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.view.View
import kotlin.math.max

/** Рисует шкалу громкости файла и показывает зоны затухания/нарастания. */
class WaveformView(ctx: Context) : View(ctx) {

    var peaks: FloatArray = FloatArray(0)
        set(v) { field = v; invalidate() }
    var fadeIn: Float = 0f
        set(v) { field = v; invalidate() }
    var fadeOut: Float = 0f
        set(v) { field = v; invalidate() }

    private val dens = resources.displayMetrics.density
    private val wave = Paint().apply { color = 0xFF1565C0.toInt(); strokeWidth = 1f }
    private val axis = Paint().apply { color = 0xFFBBBBBB.toInt(); strokeWidth = 1f }
    private val cut = Paint().apply { color = 0x66FF6F00; style = Paint.Style.FILL }
    private val edge = Paint().apply { color = 0xFFFF6F00.toInt(); strokeWidth = 2f * dens }

    init { setBackgroundColor(0xFFFFFFFF.toInt()) }

    override fun onDraw(c: Canvas) {
        val w = width
        val h = height.toFloat()
        val mid = h / 2f
        c.drawLine(0f, mid, w.toFloat(), mid, axis)

        val n = peaks.size
        if (n > 0 && w > 0) {
            for (x in 0 until w) {
                val a = (x.toLong() * n / w).toInt()
                val b = ((x + 1).toLong() * n / w).toInt().coerceAtLeast(a + 1).coerceAtMost(n)
                var p = 0f
                for (i in a until b) if (peaks[i] > p) p = peaks[i]
                val hh = p * mid
                c.drawLine(x + 0.5f, mid - hh, x + 0.5f, mid + hh, wave)
            }
        }

        val minW = 4f * dens
        if (fadeIn > 0f) {
            val fw = max(fadeIn * w, minW)
            val path = Path()
            path.moveTo(0f, 0f); path.lineTo(fw, 0f); path.lineTo(0f, h); path.close()
            c.drawPath(path, cut)
            c.drawLine(0f, h, fw, 0f, edge)
        }
        if (fadeOut > 0f) {
            val fw = max(fadeOut * w, minW)
            val wf = w.toFloat()
            val path = Path()
            path.moveTo(wf, 0f); path.lineTo(wf - fw, 0f); path.lineTo(wf, h); path.close()
            c.drawPath(path, cut)
            c.drawLine(wf - fw, 0f, wf, h, edge)
        }
    }
}
